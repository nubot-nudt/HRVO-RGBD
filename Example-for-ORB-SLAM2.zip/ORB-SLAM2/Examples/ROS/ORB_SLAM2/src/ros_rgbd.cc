/**
* This file is part of ORB-SLAM2.
*
* Copyright (C) 2014-2016 Raúl Mur-Artal <raulmur at unizar dot es> (University of Zaragoza)
* For more information see <https://github.com/raulmur/ORB_SLAM2>
*
* ORB-SLAM2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* ORB-SLAM2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with ORB-SLAM2. If not, see <http://www.gnu.org/licenses/>.
*/


#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>

#include<ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include<opencv2/core/core.hpp>

#include"../../../include/System.h"
#include <nav_msgs/Odometry.h> ///yqh
#include <tf2_ros/transform_broadcaster.h>///yqh
#include <boost/thread.hpp>///yqh

using namespace std;

class ImageGrabber
{
public:
    ImageGrabber(ORB_SLAM2::System* pSLAM):mpSLAM(pSLAM)
    {///yqh
        boost::thread t1(boost::bind(&ImageGrabber::odomAndPublish, this));
    }

    void GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD);
    struct FrameUnion///yqh
    {
        ORB_SLAM2::Frame frame;
        cv::Mat rgb;
        cv::Mat depth;
        ros::Time stamp;
        std::string frame_id;
    };
    std::list<FrameUnion> frame_buffer;///yqh
    void odomAndPublish();///yqh

    ORB_SLAM2::System* mpSLAM;
    ros::Publisher odomPub_;///yqh
    std::string odom_id;///yqh
    tf2_ros::TransformBroadcaster tfBroadcaster_odom;///yqh
    std::ofstream file_save;///yqh
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "RGBD");
    ros::start();

    if(argc != 3)
    {
        cerr << endl << "Usage: rosrun ORB_SLAM2 RGBD path_to_vocabulary path_to_settings" << endl;        
        ros::shutdown();
        return 1;
    }    

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM2::System SLAM(argv[1],argv[2],ORB_SLAM2::System::RGBD,true);

    ImageGrabber igb(&SLAM);

    ros::NodeHandle nh;

    message_filters::Subscriber<sensor_msgs::Image> rgb_sub(nh, "/camera/rgb/image_raw", 1);
    message_filters::Subscriber<sensor_msgs::Image> depth_sub(nh, "camera/depth_registered/image_raw", 1);
    typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), rgb_sub,depth_sub);
    sync.registerCallback(boost::bind(&ImageGrabber::GrabRGBD,&igb,_1,_2));
    igb.odomPub_ = nh.advertise<nav_msgs::Odometry>("odom", 1);///yqh
    ros::NodeHandle pnh("~");///yqh
    pnh.getParam( "odom_id", igb.odom_id );///yqh
    std::string file_save_name("odom.txt");///yqh
    pnh.getParam( "file_save_name", file_save_name );///yqh
    igb.file_save.open(file_save_name.c_str());///yqh
    igb.file_save << "#timestamp tx ty tz qx qy qz qw" << std::endl;///yqh
    ros::spin();

    // Stop all threads
    SLAM.Shutdown();

    // Save camera trajectory
    SLAM.SaveKeyFrameTrajectoryTUM("KeyFrameTrajectory.txt");
    igb.file_save.close();///yqh
    ros::shutdown();

    return 0;
}

void ImageGrabber::GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD)
{
    if(frame_buffer.size()<2)///yqh: we buff only 2 frames;
    {
        // Copy the ros image message to cv::Mat.
        cv_bridge::CvImageConstPtr cv_ptrRGB;
        try
        {
            cv_ptrRGB = cv_bridge::toCvShare(msgRGB);
        }
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }

        cv_bridge::CvImageConstPtr cv_ptrD;
        try
        {
            cv_ptrD = cv_bridge::toCvShare(msgD);
        }
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        ORB_SLAM2::Frame frame = mpSLAM->mpTracker->prepareFrame( cv_ptrRGB->image,cv_ptrD->image,cv_ptrRGB->header.stamp.toSec() );///yqh
        FrameUnion frameU;
        frameU.rgb = cv_ptrRGB->image.clone();
        frameU.depth=cv_ptrD->image.clone();
        frameU.stamp=cv_ptrRGB->header.stamp;
        frameU.frame_id=cv_ptrRGB->header.frame_id;
        frameU.frame=frame;
        frame_buffer.push_back( frameU );
    }
    ///
}
void ImageGrabber::odomAndPublish()///yqh
{
    while(1)
    if( frame_buffer.size()>0 )
    {
        ros::Time time_start = ros::Time::now ();
        FrameUnion _frame_union = frame_buffer.front();
        cv::Mat Tcw_yqh = mpSLAM->TrackRGBD( _frame_union.rgb,_frame_union.depth,_frame_union.stamp.toSec(), &_frame_union.frame);
        frame_buffer.pop_front();

        if( !Tcw_yqh.empty() )
        {
            cv::Mat Twc_yqh = Tcw_yqh.inv();
            Eigen::MatrixXf Tcw_eigen = Eigen::Map<Eigen::MatrixXf>( (float*)Twc_yqh.data, 4, 4 );//eig矩阵默认按列存储 (4,4,CV_32F)
            Eigen::Matrix3f Tf_my2show;// Warning!!! x=z y=-x z=-y
            Tf_my2show << 0, 0,1,
                    -1, 0,0,
                    0,-1,0;
            //    Tf_my2show << 1, 0,0,
            //                  0, 1,0,
            //                  0, 0,1;
            Eigen::Vector3f position   ( Tcw_eigen(3,0), Tcw_eigen(3,1), Tcw_eigen(3,2) );//eig矩阵默认按列存储
            position = Tf_my2show*position;
            Tcw_eigen.conservativeResize( 3, 3 );
            Eigen::Matrix3f R_eigen = Tf_my2show*Tcw_eigen.transpose();//eig矩阵默认按列存储
            Eigen::Quaternionf orientation( R_eigen );

            geometry_msgs::Transform odom_pos;
            odom_pos.translation.x = position(0);
            odom_pos.translation.y = position(1);
            odom_pos.translation.z = position(2);
            odom_pos.rotation.x = orientation.x();
            odom_pos.rotation.y = orientation.y();
            odom_pos.rotation.z = orientation.z();
            odom_pos.rotation.w = orientation.w();

            geometry_msgs::TransformStamped tf_odom;
            tf_odom.header.stamp = _frame_union.stamp; // use corresponding time stamp to image
            tf_odom.header.frame_id = odom_id;
            tf_odom.child_frame_id = _frame_union.frame_id;
            //    tf_odom.transform = odom_pos;
            tf_odom.transform.translation.x = 0;
            tf_odom.transform.translation.y = 0;
            tf_odom.transform.translation.z = 0;
            tf_odom.transform.rotation.x = 0;
            tf_odom.transform.rotation.y = 0;
            tf_odom.transform.rotation.z = 0;
            tf_odom.transform.rotation.w = 1;
            tfBroadcaster_odom.sendTransform(tf_odom);

            if(odomPub_.getNumSubscribers())
            {
                nav_msgs::Odometry odom;
                odom.header.stamp = tf_odom.header.stamp;
                odom.header.frame_id = tf_odom.header.frame_id;
                odom.child_frame_id = tf_odom.child_frame_id;
                odom.pose.pose.position.x = odom_pos.translation.x;
                odom.pose.pose.position.y = odom_pos.translation.y;
                odom.pose.pose.position.z = odom_pos.translation.z;
                odom.pose.pose.orientation = odom_pos.rotation;
                odomPub_.publish(odom);
            }

            file_save << std::fixed;
            file_save << std::setprecision(4) << tf_odom.header.stamp.toSec() << " " << odom_pos.translation.x << " " << odom_pos.translation.y << " " << odom_pos.translation.z
                      << " " << odom_pos.rotation.x << " " << odom_pos.rotation.y << " " << odom_pos.rotation.z << " " << odom_pos.rotation.w << std::endl;
        }

        ros::Time time_end = ros::Time::now ();
        std::cout << "time cost = " << ( time_end.toSec()-time_start.toSec() )*1000 << "ms, fps=" << 1 / ( time_end.toSec()-time_start.toSec() ) << std::endl;
    }
    else
        usleep(3000);
}
